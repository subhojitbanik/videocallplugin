<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Join With Meeting Code!</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href="./style.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://sdk.twilio.com/js/video/releases/2.17.1/twilio-video.min.js"></script>
</head>

<body>
    <div class="container">
        <div class="row">
            <form class="row g-3" action="join.php" method="GET">
                <div class="col-md-6">
                    <h2>Join With Meeting Code</h2>
                    <div class="col-md-6">
                        <input type="text" name="rname" class="form-control" id="roomID" placeholder="Enter Meeting Code">
                        <input type="hidden" id="audio_val" name="audioStatus" value="">
                        <input type="hidden" id="video_val" name="videoStatus" value="">
                        <input type="hidden" id="token" name="token" value="<?php echo uniqid();?>">
                    </div>
                    <div class="col-md-12">
                        <input type="submit" name="submit" value="Join" class="btn btn-primary">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="localframe">
                        <div id="local-media"></div>
                        <div class="controls">
                            <div class="sb-call-audio" id="disconnect-sb-call-audio">
                                <span class="material-icons">mic</span>
                            </div>
                            <div class="sb-call-audio" id="connect-sb-call-audio" style="display:none">
                                <span class="material-icons">mic_off</span>
                            </div>
                            <div class="sb-call-video" id="disconnect-sb-call-video">
                                <span class="material-icons">videocam</span>
                            </div>
                            <div class="sb-call-video" id="connect-sb-call-video" style="display:none">
                                <span class="material-icons">videocam_off</span>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</body>

<script>
    const Video = Twilio.Video;
    Video.createLocalTracks().then(function(localTracks) {
        var localMediaContainer = document.getElementById('local-media');
        localTracks.forEach(function(track) {
            var trackElement = track.attach();
                //console.log(trackElement);
                trackElement.style.transform = 'scale(-1, 1)';
            localMediaContainer.appendChild(trackElement);
            //Show/Hide Video starts
            $('#disconnect-sb-call-video').on('click', () => {
               // alert('triggered');
                localTracks[1].disable();
                jQuery('#video_val').val(localTracks[1].isEnabled);
                jQuery('#disconnect-sb-call-video').hide();
                jQuery('#connect-sb-call-video').show();
                
                console.log(localTracks[1].isEnabled);
            })
            $('#connect-sb-call-video').on('click', () => {
               // alert('triggered');
                localTracks[1].enable();
                jQuery('#video_val').val(localTracks[1].isEnabled);
                jQuery('#connect-sb-call-video').hide();
                jQuery('#disconnect-sb-call-video').show();
                console.log(localTracks[1].isEnabled);
            })
            //Show/Hide Video ends
            //mute/unmute audio starts
            $('#disconnect-sb-call-audio').on('click', () => {
               // alert('triggered');
                localTracks[0].disable();
                jQuery('#audio_val').val(localTracks[0].isEnabled);
                //console.table(localTracks[0].isEnabled);
                jQuery('#disconnect-sb-call-audio').hide();
                jQuery('#connect-sb-call-audio').show();
            })
            $('#connect-sb-call-audio').on('click', () => {
            //    alert('triggered');
                localTracks[0].enable();
                jQuery('#audio_val').val(localTracks[0].isEnabled);
                jQuery('#connect-sb-call-audio').hide();
                jQuery('#disconnect-sb-call-audio').show();
            })
            //mute/unmute audio ends

        });
    });
</script>




</html>