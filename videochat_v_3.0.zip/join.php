<?php
session_start();
// Get the PHP helper library from https://twilio.com/docs/libraries/php
require_once 'vendor/autoload.php'; // Loads the library
use Twilio\Jwt\AccessToken;
use Twilio\Jwt\Grants\VideoGrant;

// Required for all Twilio access tokens
// To set up environmental variables, see http://twil.io/secure
// $twilioAccountSid = getenv('TWILIO_ACCOUNT_SID');
// $twilioApiKey = getenv('TWILIO_API_KEY');
// $twilioApiSecret = getenv('TWILIO_API_KEY_SECRET');

$twilioAccountSid = 'AC9c033c4d217dbbd6ccbab7cde26f1f82';
$twilioApiKey = 'SKfc3420064d81057235d9602bea61b7be';
$twilioApiSecret = 'ZTFrwwhNbCBquqg9oMgugAW4SnXx9E9T';

// Required for Video grant
$_SESSION["rname"] = $_GET['rname'];
$_SESSION["identity"] = $_GET['token'];
$roomName = $_SESSION["rname"];
// An identifier for your app - can be anything you'd like
$identity = $_SESSION["identity"];

// Create access token, which we will serialize and send to the client
$token = new AccessToken(
    $twilioAccountSid,
    $twilioApiKey,
    $twilioApiSecret,
    3600,
    $identity
);

// Create Video grant
$videoGrant = new VideoGrant();
$videoGrant->setRoom($roomName);

// Add grant to token
$token->addGrant($videoGrant);

// render token to string
$_SESSION['token'] = $token->toJWT();
?>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Meeting Room</title>
    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous"> -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=DM+Sans:400,500,700&display=swap" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="./style.css" rel="stylesheet">
    <!-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script> -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://sdk.twilio.com/js/video/releases/2.17.1/twilio-video.min.js"></script>
</head>

<body>
    <!-- <div class="container">
        <div class="videofrme my-30">
            <div class="row ">
                <div class="col-lg-9 col-md-9 col-sm-12">
                    <div class="remote-stream">
                        <div id="remote-media-div"></div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-12">
                    <div class="local-stream">
                        <div id="local-media"></div>
                    </div>
                </div>
                <div class="col-lg-12 col-md-12 col-sm-12">
                    <div class="controls">
                        <button class="sb-call-audio" id="disconnect-sb-call-audio">
                            <span class="material-icons">mic</span>
                        </button>
                        <button class="sb-call-audio" id="connect-sb-call-audio" style="display:none">
                            <span class="material-icons">mic_off</span>
                        </button>
                        <button class="sb-call-video" id="disconnect-sb-call-video">
                            <span class="material-icons">videocam</span>
                        </button>
                        <button class="sb-call-video" id="connect-sb-call-video" style="display:none">
                            <span class="material-icons">videocam_off</span>
                        </button>
                        <button class="sb-call-video" id="connect-sb-screen-share">
                            <span class="material-icons">screen_share</span>
                        </button>
                        <button class="sb-call-end" id="disconnect">
                            <span class="material-icons">call_end</span>
                        </button>

                    </div>
                </div>
            </div>
        </div>
    </div> -->
    <div class="app-container">
        <div class="app-main">
            <div class="video-call-wrapper">
                <!-- Remoteclient media starts -->
                <div class="video-participant local contain" id="contain">
                    <div class="participant-actions">
                        <button class="btn-mute"></button>
                        <button class="btn-camera"></button>
                        <!-- <a href="#" class="name-tag">Andy Will</a> -->
                    </div>

                    <div class="participant" id="remote-media-div" style="display: flex;width: 100%;height: 100%;"></div>


                </div>
                <!-- Remoteclient media ends -->
                <!-- Localclient media starts -->
                <div class="video-participant client">
                    <div class="participant-details">
                        <a href="#" class="name-tagg">Emmy Lou</a>
                    </div>
                    <div class="participant-actions">
                        <button class="btn-mute"></button>
                        <button class="btn-camera"></button>
                    </div>
                    <div>
                        <div id="local-media"></div>
                    </div>

                </div>
                <!-- Localclient media ends -->
            </div>
            <div class="video-call-actions controls">
                <button class="sb-call-audio" id="disconnect-sb-call-audio">
                    <span class="material-icons">mic</span>
                </button>
                <button class="sb-call-audio" id="connect-sb-call-audio" style="display:none">
                    <span class="material-icons">mic_off</span>
                </button>
                <button class="sb-call-video" id="disconnect-sb-call-video">
                    <span class="material-icons">videocam</span>
                </button>
                <button class="sb-call-video" id="connect-sb-call-video" style="display:none">
                    <span class="material-icons">videocam_off</span>
                </button>
                <button class="sb-call-video material-icons " id="connect-sb-screen-share">
                    screen_share
                </button>
                <!-- <button class="sb-call-video material-icons " id="disconnect-sb-screen-share" style="display:none">
                    stop_screen_share
                </button> -->
                <button class="sb-call-end" id="disconnect">
                    <span class="material-icons">call_end</span>
                </button>
            </div>
        </div>
    </div>

    <script>
        // Getting audio/video status
        var AudioStatus = "<?php echo $_GET['audioStatus'] ?>";
        var VideoStatus = "<?php echo $_GET['videoStatus'] ?>";

        //console.log(AudioStatus, VideoStatus);
        // Setting constants
        const Video = Twilio.Video;
        // Request audio and video tracks
        Video.createLocalTracks().then(function(localTracks) {
            var localMediaContainer = document.getElementById('local-media');
            localTracks.forEach(function(track) {
                var trackElement = track.attach();
                localMediaContainer.appendChild(trackElement);
            });
            return Video.connect('<?php echo $_SESSION['token']; ?>', {
                name: '<?php echo $roomName; ?>',
                tracks: localTracks,
                audio: true,
                video: {
                    width: 640
                },
                bandwidthProfile: {
                    video: {
                        mode: 'presentation',
                        dominantSpeakerPriority: 'standard'
                    }
                },
                dominantSpeaker: true,
            }).then(function(room) {
                    //console.log(`Connected to Room: ${room.name}`);
                    const localParticipant = room.localParticipant;
                    // Assign constant
                    const shareScreen = document.getElementById('connect-sb-screen-share');
                    var screenTrack;
                    shareScreen.addEventListener('click', shareScreenHandler);
                    // Function for share screen
                    function shareScreenHandler() {
                        event.preventDefault();
                        if (!screenTrack) {
                            navigator.mediaDevices.getDisplayMedia({
                                video: {
                                    frameRate: 15,
                                    zoom: true
                                }
                            }).then(stream => {
                                screenTrack = new Video.LocalVideoTrack(stream.getTracks()[0]);
                                //console.log(stream);
                                //screenTrack.classList.add('participantZoomed')
                                room.localParticipant.publishTrack(screenTrack, {
                                    name: 'screen', // Tracks can be named to easily find them later
                                    priority: 'high', // Priority is set to high by the subscriber when the video track is rendered
                                });
                                shareScreen.innerHTML = 'stop_screen_share';
                                screenTrack.mediaStreamTrack.onended = () => {
                                    shareScreenHandler()
                                };
                                room.localParticipant.videoTracks.forEach(publication => {
                                    publication.track.disable();
                                });
                            }).catch(() => {
                                alert('Could not share the screen.');
                            });

                        } else {
                            room.localParticipant.unpublishTrack(screenTrack);
                            screenTrack.stop();
                            screenTrack = null;
                            shareScreen.innerHTML = 'screen_share';
                            room.localParticipant.videoTracks.forEach(publication => {
                                publication.track.enable();
                            });
                        }
                    };
                    //Checking Audio Status After Room Connect.
                    if (AudioStatus == "true") {
                        room.localParticipant.audioTracks.forEach(publication => {
                            publication.track.enable();
                        });
                        jQuery('#connect-sb-call-audio').hide();
                        jQuery('#disconnect-sb-call-audio').show();
                    } else if (AudioStatus == "false") {
                        room.localParticipant.audioTracks.forEach(publication => {
                            publication.track.disable();
                        });
                        jQuery('#disconnect-sb-call-audio').hide();
                        jQuery('#connect-sb-call-audio').show();
                    } else if (AudioStatus == " ") {
                        room.localParticipant.audioTracks.forEach(publication => {
                            publication.track.enable();
                        });
                        jQuery('#connect-sb-call-audio').hide();
                        jQuery('#disconnect-sb-call-audio').show();
                    }
                    //Checking Video Status After Room Connect.
                    if (VideoStatus == "true") {
                        room.localParticipant.videoTracks.forEach(publication => {
                            publication.track.enable();
                        });
                        jQuery('#connect-sb-call-video').hide();
                        jQuery('#disconnect-sb-call-video').show();
                    } else if (VideoStatus == "false") {
                        room.localParticipant.videoTracks.forEach(publication => {
                            publication.track.disable();
                        });
                        jQuery('#disconnect-sb-call-video').hide();
                        jQuery('#connect-sb-call-video').show();
                    } else if (VideoStatus == " ") {
                        room.localParticipant.videoTracks.forEach(publication => {
                            publication.track.enable();
                        });

                        jQuery('#connect-sb-call-video').hide();
                        jQuery('#disconnect-sb-call-video').show();
                    }
                    // Attach the Participant's Media to a <div> element.
                    room.on('participantConnected', participant => {
                        //console.log(`Participant "${participant.identity}" connected`);
                        room.participants.forEach(participant => {
                            //console.log(participant.tracks);
                            participant.tracks.forEach(publication => {
                                if (publication.isSubscribed) {
                                    const track = publication.track;
                                    var trackElement = track.attach();
                                    // console.log('host Connected participant track publication ' + trackElement);
                                    trackElement.addEventListener('click', () => {
                                        zoomTrack(trackElement)
                                    });
                                    document.getElementById('remote-media-div').appendChild(trackElement);
                                }
                            });
                            participant.on('trackSubscribed', track => {
                                var trackElement = track.attach();
                                // console.log('host Connected participant track subscribed ' + track);
                                trackElement.addEventListener('click', () => {
                                    zoomTrack(trackElement)
                                });
                                document.getElementById('remote-media-div').appendChild(trackElement);
                            });
                            participant.on('trackUnsubscribed', (track) => {
                                track.detach().forEach(element => element.remove());
                            });
                        })
                    });

                    room.participants.forEach(participant => {
                        participant.tracks.forEach(publication => {
                            if (publication.track) {
                                var trackElement = track.attach();
                                // console.log('guest publication track' + trackElement);
                                trackElement.addEventListener('click', () => {
                                    //alert('clicked');
                                    zoomTrack(trackElement)
                                });
                                document.getElementById('remote-media-div').appendChild(trackElement);
                            }
                        });
                        //on track subscribed.
                        participant.on('trackSubscribed', track => {
                            var trackElement = track.attach();
                            // console.log('guest track subscribed ' + trackElement);
                            trackElement.addEventListener('click', () => {
                                //alert('clicked');
                                zoomTrack(trackElement)
                            });
                            document.getElementById('remote-media-div').appendChild(trackElement).className = "screenshare";
                        });
                        participant.on('trackUnsubscribed', (track) => {
                            track.detach().forEach(element => element.remove());
                        });
                    });

                    //function for zoomTrack
                    function zoomTrack(trackElement) {
                        if (!trackElement.classList.contains('participantZoomed')) {
                            //console.log(container.childNodes);
                            // zoom in
                            contain.childNodes.forEach(participant => {

                                if (participant.className == 'participant') {
                                    participant.childNodes.forEach(track => {
                                        console.log(track);
                                        if (track === trackElement) {
                                            track.classList.add('participantZoomed')
                                        } 
                                        // else {
                                        //     track.classList.add('participantHidden')
                                        // }
                                    });
                                    //participant.childNodes[1].classList.add('participantHidden');
                                }
                            });

                        } else {
                            contain.childNodes.forEach(participant => {
                                if (participant.className == 'participant') {
                                    participant.childNodes.forEach(track => {
                                        console.log(trackElement);
                                        if (track === trackElement) {
                                            track.classList.remove('participantZoomed');
                                        } 
                                        // else {
                                        //     track.classList.remove('participantHidden');
                                        // }
                                    });
                                    //participant.childNodes[1].classList.remove('participantHidden');
                                }
                            });
                        }
                    }
                    // dominant speaker
                    room.on('dominantSpeakerChanged', participant => {
                        console.log('The new dominant speaker in the Room is:', participant);
                    });
                    //dominant speaker
                    // Detach the Participant's Media from <div> element.
                    room.on('disconnected', room => {
                        // Detach the local media elements
                        room.localParticipant.tracks.forEach(publication => {
                            const attachedElements = publication.track.detach();
                            attachedElements.forEach(element => element.remove());
                        });

                    });
                    // Track unsubscribe.

                    // Trigger end call button.
                    $('#disconnect').on('click', () => {
                        //alert('triggered');
                        room.disconnect();
                        window.location.href = "https://fastgrades.net/videochat/";
                        //jQuery('#remote-media-div').empty();
                    });
                    //Trigger audio mute
                    $('#disconnect-sb-call-audio').on('click', () => {
                        //alert('triggered');
                        room.localParticipant.audioTracks.forEach(publication => {
                            publication.track.disable();
                        });
                        jQuery('#disconnect-sb-call-audio').hide();
                        jQuery('#connect-sb-call-audio').show();
                    })
                    //Trigger audio unmute
                    $('#connect-sb-call-audio').on('click', () => {
                        //alert('triggered');
                        room.localParticipant.audioTracks.forEach(publication => {
                            publication.track.enable();
                        });
                        jQuery('#connect-sb-call-audio').hide();
                        jQuery('#disconnect-sb-call-audio').show();
                    })

                    //Trigger video hide
                    $('#disconnect-sb-call-video').on('click', () => {
                        //alert('triggered');
                        room.localParticipant.videoTracks.forEach(publication => {
                            publication.track.disable();
                        });
                        jQuery('#disconnect-sb-call-video').hide();
                        jQuery('#connect-sb-call-video').show();
                    })
                    //Trigger video unhide
                    $('#connect-sb-call-video').on('click', () => {
                        //alert('triggered');
                        room.localParticipant.videoTracks.forEach(publication => {
                            publication.track.enable();
                        });
                        jQuery('#connect-sb-call-video').hide();
                        jQuery('#disconnect-sb-call-video').show();
                    })
                    // $('#connect-sb-screen-share').on('click', () => {
                    //     room.localParticipant.videoTracks.forEach(publication => {
                    //         publication.track.disable();
                    //     });
                    //     $('.clicked').removeClass('connect-sb-screen-share');
                    //     jQuery('#connect-sb-screen-share').hide();
                    //     jQuery('#disconnect-sb-screen-share').show();
                    // })
                    // $('#disconnect-sb-screen-share').on('click', () => {
                    //     room.localParticipant.videoTracks.forEach(publication => {
                    //         publication.track.enable();
                    //     });
                    //     $('.clicked').removeClass('connect-sb-screen-share');
                    //     jQuery('#disconnect-sb-screen-share').hide();
                    //     jQuery('#connect-sb-screen-share').show();
                    // })

                },
                function(error) {
                    console.error('Unable to connect to Room: ' + error.message);
                });
        });
    </script>

</body>

</html>
<?php
//print_r($_SESSION);
session_unset();
session_destroy();
?>