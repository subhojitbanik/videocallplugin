<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>time Frame</title>
</head>

<?php
$tutor = "tutor@fastgrades.net";
$student = "student@fastgrades.net";
    date_default_timezone_set('Asia/Kolkata');
    $current_time = date('H:i');
    //sleep(15);
    //flush();
    // echo "<br>";
    // echo'current time '. $current_time;
    $min_val = $_POST['tmin'];
    $max_val = $_POST['tmax'];
    $user = $_POST['username'];
    if (isset($_POST['submit'])) {
        # code...
        if ($current_time < $min_val) {
            $msg = '<h2 style="text-align:center">Can not Proceed, You came too Early!</h2>';
        } elseif ($current_time > $max_val) {
            $msg = '<h2 style="text-align:center">Following Link has Expired</h2>';
        } elseif ($current_time >= $min_val && $current_time <= $max_val) {
            //echo 'You can proceed';
            if(($user == $tutor) || ($user == $student)){
                header("Location: createroom.php");
                die();
            }else{
                $msg = '<h2 style="text-align:center">This session is not assigned for you!</h2>';
            }


            
        }
    }
    ?>
<body>
    <div class="time" style="text-align:center; display:block;">
        <form action="timeframe.php" method="post">
            <label>Enter username</label><small>e.g: student@fastgrades.net</small>
            <input type="email" name="username">
            <br><br>
            <label for="appt">Time From:</label>
            <input type="time" id="appt" name="tmin" value="<?php echo $min_val;?>">
            <br><br>
            <label for="appt">Time To:</label>
            <input type="time" id="appt" name="tmax" value="<?php echo $max_val;?>">
            <br><br>
            <input type="submit" name="submit" value="Proceed to join">
        </form>
        <?php echo $msg; ?>
    </div>

</body>

</html>