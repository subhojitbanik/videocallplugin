<script src="//sdk.twilio.com/js/video/releases/2.17.1/twilio-video.min.js"></script>

<?php
session_start();
// Update the path below to your autoload.php,
// see https://getcomposer.org/doc/01-basic-usage.md
require_once 'vendor/autoload.php';

use Twilio\Rest\Client;
// // Find your Account SID and Auth Token at twilio.com/console
// // and set the environment variables. See http://twil.io/secure
$sid = "AC9c033c4d217dbbd6ccbab7cde26f1f82";
$token = "c5a06e2f29b75e31c30670545e174525";
// $twilioAccountSid = 'AC9c033c4d217dbbd6ccbab7cde26f1f82';
// $twilioApiKey = 'SKfc3420064d81057235d9602bea61b7be';
// $twilioApiSecret = 'ZTFrwwhNbCBquqg9oMgugAW4SnXx9E9T';

$twilio = new Client($sid, $token);

?>

<html>

<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="./style.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
</head>

<body>
    <div class="container">
        <div class="row">
            <?php

            if (isset($_POST['submit'])) {
                
                $uni_room_name = $_POST['room'];
                //echo $uni_room_name;
                $room = $twilio->video->v1->rooms->create(
                    [
                        "type" => "go",
                        "statusCallback" => "http://localhost/roomsessions.php",
                        "uniqueName" => $uni_room_name,
                        "maxParticipantDuration" => 3600,
                        "duration" => 3600,
                        "unusedRoomTimeout" => 60,
                        "emptyRoomTimeout" => 10,
                    ]
                );
                $roomID = ($room->sid);
                $_SESSION["rname"]=($room->uniqueName);
                $roomName = $_SESSION["rname"];
            ?>
            <?php
                //echo '<h4>Room Id:' . $roomID . ' </h4>';
                echo '<div class="col-md-12"><div class="content-copy">';
                echo '<h4>Meeting Code: </h4>' . '<input type="text" value="' . $roomName . '" id="myInput" readonly>';
                echo '<div class="tooltip">
                        <button class="btn btn-primary btn-lg btn-md btn-sm " onclick="myFunction()" onmouseout="outFunc()">
                            <span class="tooltiptext" id="myTooltip">Copy to clipboard</span>
                            <span class="material-icons"> content_copy</span>
                        </button>
                    </div>
                </div></div>';
                //echo '<h5> Room Link : <a href="' . $room->url . '">' . $room->url . '</a></h5>';
                echo '<h5> <a href="join.php?rname=' . $roomName . '">Join meeting</a></h5>';
            }
            ?>
            <div class="col-md-12">
                <form class="row g-3" id="fcreate" action="" method="POST">
                    <h2>Create Meeting Room</h2>
                    <div class="col-md-6">
                        <input type="text" name="room" class="form-control" id="roomID" placeholder="Enter Room Name">
                    </div>
                    <div class="col-md-12">
                        <input type="submit" name="submit" value="Create" class="btn btn-primary">
                    </div>
                </form>
            </div>
            <hr>
            <div class="col-md-12">
                <h2>Alreardy Having Meeting Code!</h2>
                <div class="code-butn">
                    <a class="btn btn-info btn-lg btn-md- btn-sm" href="joincode.php">Join With Meeting Code</a>
                </div>
            </div>
        </div>
    </div>

    <script>
        function myFunction() {
            var copyText = document.getElementById("myInput");
            copyText.select();
            copyText.setSelectionRange(0, 99999);
            navigator.clipboard.writeText(copyText.value);

            var tooltip = document.getElementById("myTooltip");
            tooltip.innerHTML = "Copied: " + copyText.value;
        }

        function outFunc() {
            var tooltip = document.getElementById("myTooltip");
            tooltip.innerHTML = "Copy to clipboard";
        }
    </script>
</body>

</html>