<?php

// echo $roomName;
// Update the path below to your autoload.php,
// see https://getcomposer.org/doc/01-basic-usage.md
require_once 'vendor/autoload.php';

use Twilio\Rest\Client;
// // Find your Account SID and Auth Token at twilio.com/console
// // and set the environment variables. See http://twil.io/secure
$sid = "AC9c033c4d217dbbd6ccbab7cde26f1f82";
$token = "c5a06e2f29b75e31c30670545e174525";
$twilio = new Client($sid, $token);
$rooms = $twilio->video->v1->rooms->read(["status" => "completed"]);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Room Sessions</title>
    <style>
        h5 {
            margin: 5px auto;
        }

        .wrapper {
            width: 100%;
        }

        .pwrapper {
            width: 48%;
            margin: 0 0.5%;
            float: left;
            overflow-wrap: break-word;
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="row">
            <form action="" method="post">
                <label>Select Room Name</label>
                <select name="roomlist">
                    <option value="">Select Room Name</option>
                    <?php foreach ($rooms as $record) {
                        echo '<option value="' . $record->sid . '">' . $record->uniqueName . '</option>';
                    } ?>
                </select>
                <input type="submit" name="submit" value="See Room Details">
            </form>

            <?php
            $selectroom = $_POST['roomlist'];
            if (isset($_POST["submit"])) {
                //$twilio = new Client($sid, $token);
                $roomdetails = $twilio->video->v1->rooms($selectroom)->fetch();
                //echo '<pre>';
                //print_r($roomdetails);
                //print($roomdetails->uniqueName);
                $participantDetails = $twilio->video->v1->rooms($selectroom)->participants->read();

            ?>
                <div class="room_details" style="text-align: left;">
                    <h5>Room Name : <?php echo $roomdetails->uniqueName; ?></h5>
                    <h5>Created At: <?php  //var_dump($roomdetails->dateCreated);
                                    date_default_timezone_set('Asia/Kolkata');
                                    $mydate = $roomdetails->dateCreated;
                                    echo $mydate->format('Y-m-d H:i:s A');
                                    ?></h5>
                    <h5>End Time : <?php $mydate = $roomdetails->endTime;
                                    echo $mydate->format('Y-m-d H:i:s A');
                                    ?></h5>
                    <h5>Durations : <?php echo $roomdetails->duration . ' Seconds'; ?></h5>
                    <h4>Participant Details</h4>
                    <?php
                    //echo '<pre>';
                    //print_r($participantDetails);
                    echo '<div class="wrapper">';
                    foreach ($participantDetails as $participant) {
                        echo '<div class="pwrapper">';
                        echo '<h5> Participants Name : ' . $participant->identity . '</h5>';
                        echo '<h5> Participants ID : ' . $participant->sid . '</h5>';
                        echo '<h5> Participants Room ID : ' . $participant->roomSid . '</h5>';
                        echo '<h5> Status : ' . $participant->status . '</h5>';
                        echo '<h5> Start Time : ' . $participant->startTime->format('Y-m-d H:i:s A') . '</h5>';
                        echo '<h5> End Time : ' . $participant->endTime->format('Y-m-d H:i:s A') . '</h5>';
                        echo '<h5> Call duration : ' . $participant->duration . ' seconds</h5>';
                        echo'<h5>Extras</h5>';
                        echo '<h5> participant details url : '.$participant->url.'</h5>';
                              $links = $participant->links;
                            //   echo"<pre>";
                            //   print_r($links);
                              
                                echo'<h5><a href="'.$links["subscribed_tracks"].'" target="_blank">Click for Subscribed Tracks details </a></h5>';
                                echo'<h5><a href="'.$links["published_tracks"].'" target="_blank">Click for Published Tracks details</a></h5>';
                                echo'<h5><a href="'.$links["subscribe_rules"].'" target="_blank">Click for Subscribed Rules details</a></h5>';
                              
                        echo '<hr></div>';                                                
                    }
                    echo '</div >';
                    ?>
                </div>


            <?php } ?>
        </div>
    </div>
</body>

</html>