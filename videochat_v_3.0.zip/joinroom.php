<script src="//sdk.twilio.com/js/video/releases/2.17.1/twilio-video.min.js"></script>

<?php
$token = $_GET['token'];
echo 'sbrm : ' . $rname = $_GET['rname'];
echo 'identity : ' . $identity = $_GET['identity'];

?>


<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous"> -->
    <link href="https://fonts.googleapis.com/css?family=DM+Sans:400,500,700&display=swap" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
</head>


<body>
    <div class="container">
        <div class="row">
            <div id="preview">
                <div id="local-media"></div>

            </div>
            <form action="" method="post">
                <input type="text" name="" id="">
                <input type="submit" value="">
            </form>
            <div id="remote-media"></div>
        </div>
    </div>
    <script>
        const Video = Twilio.Video;

        Video.connect('<?php echo $token; ?>', {
            name: '<?php echo $rname; ?>',
            audio: true,
            video: {
                width: 640
            }
        }).then(function(room) {
            console.log(`Connected to Room: ${room.name}`);
            const localParticipant = room.localParticipant;
            console.log(`Connected to the Room as LocalParticipant "${localParticipant.identity}"`);
            console.log(room.participants);



            // Log new Participants as they connect to the Room
            room.once('participantConnected', participant => {
                console.log(`Participant "${participant.identity}" has connected to the Room`);
                console.log(`"${participant.tracks}"`);
                participant.tracks.forEach(publication => {
                    if (publication.isSubscribed) {
                        const track = publication.track;
                        document.getElementById('remote-media').appendChild(track.attach());
                    }
                });
            });


        }, function(error) {
            console.error('Unable to connect to Room: ' + error.message);
        });



        //var Video = require('twilio-video');
        // Request audio and video tracks
        Video.createLocalTracks().then(function(localTracks) {
            var localMediaContainer = document.getElementById('local-media');
            localTracks.forEach(function(track) {
                localMediaContainer.appendChild(track.attach());
            });
        });
    </script>
</body>

</html>